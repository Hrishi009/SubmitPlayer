//
//  ViewController.swift
//  MPPlay
//
//  Created by Gaurav kive on 17/04/18.
//  Copyright © 2018 Gaurav kive. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
   fileprivate let myMediaPlayer = MPMusicPlayerApplicationController.applicationQueuePlayer
   fileprivate var arrSongs: [MPMediaItem]?
    
    @IBOutlet var tblView: UITableView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getSongs()
        setupCommandCenter()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
    }
    
    /// UITableViewData Source functions
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var rowCount = 0
        
        if let arr = arrSongs
        {
            rowCount = arr.count
        }
       
        return rowCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell?
        cell = tableView.dequeueReusableCell(withIdentifier: "Music Cell")
        if cell == nil
        {
            cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "Music Cell")
        }
        cell?.textLabel?.text = arrSongs![indexPath.row].title
        return cell!
    }
    
    /// UITableView Delegate functions
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedItm = arrSongs![indexPath.row]
        let collection = MPMediaItemCollection(items: [selectedItm])
        myMediaPlayer.setQueue(with: collection)
         myMediaPlayer.play()
    }
    
   private func  PlayAudio()
    {
        // Instantiate a new music player
        
        // Add a playback queue containing all songs on the device
        myMediaPlayer.setQueue(with: MPMediaQuery.songs())
        
        myMediaPlayer.play()
    }
    
    // Get songs from music library
   private func getSongs()
    {
        let query = MPMediaQuery.songs()
        if let items = query.items{
            arrSongs = items
            self.tblView?.reloadData()
        }
        
    }
    
    @IBAction func plAGeet()
    {
        
        self.PlayAudio()
        
        self.getSongs()
    }
    
   // To set audio session for background mode
    func setupCommandCenter() {
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [MPMediaItemPropertyTitle: "MPPlay"]
        
        let commandCenter = MPRemoteCommandCenter.shared()
        commandCenter.playCommand.isEnabled = true
        commandCenter.pauseCommand.isEnabled = true
        commandCenter.playCommand.addTarget { [weak self] (event) -> MPRemoteCommandHandlerStatus in
            self?.myMediaPlayer.play()
            return .success
        }
        commandCenter.pauseCommand.addTarget { [weak self] (event) -> MPRemoteCommandHandlerStatus in
            self?.myMediaPlayer.pause()
            return .success
        }
    }
}

